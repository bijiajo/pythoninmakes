from django.apps import AppConfig


class TodoprojectappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'todoprojectapp'
